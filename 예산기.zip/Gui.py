from tkinter import *

from PIL import ImageTk, Image

def del_digit():
    input_entry.delete(0, END)
    result_label.config(text="")

def calculate():
    result = eval(input_entry.get())
    result_label.config(text=result)

def clicked(digit):
    if digit == 'C':
        command=del_digit()
    elif digit == '=':
        command = calculate()

    else:
        input_entry.insert(END, digit)


window = Tk()
window.title('계산기')
window.resizable(False, False)
window.config(padx=10, pady=10)
window.geometry("500x500")

img =Image.open('ye.jpg')
bg = ImageTk.PhotoImage(img)

label = Label(window, image=bg)
label.place(x = -12,y = -12)

digits = [
    ['7','8','9','/'],
    ['4','5','6','*'],
    ['1','2','3','-'],
    ['C','0','=','+']
]

input_entry = Entry(window, width=23, font=("나눔바른펜", 20), justify=RIGHT)
input_entry.grid(column=0, row=0, columnspan=4)
input_entry.focus()

result_label = Label(window, text="", width=20, font=("나눔바른펜",30))
result_label.grid(column=0, row=1, columnspan=4)

for r in range(4):
    for c in range(4):
        digit = digits[r][c]
        button = Button(window, text=digit, width=8, font=("나눔바른펜",15), command=lambda x=digit: clicked(x))
        button.grid(row=r+2, column=c)
    '''button.place(y=90)'''

window.mainloop()